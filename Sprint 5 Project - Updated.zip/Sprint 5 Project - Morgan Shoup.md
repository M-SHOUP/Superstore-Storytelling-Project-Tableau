README.MD

# Project 5 SuperStore Analysis  

## 📌 Overview  
This project analyzes the high number of returned orders at the Superstore. The goal is to provide the CEO
with insights into return patterns, identify root causes, and propose solutions to reduce the volume of returns.
Using a combination of data visualization techniques in Tableau, this analysis explores geographic, seasonal,
and product-based return trends.
---

## 📊 Tableau Public Links  
Below is the link to my Tableau Project:  

https://public.tableau.com/app/profile/morgan.shoup/viz/Project5_17411255550320/Scatterplot
   - Includes 7 worksheets, 1 dashboard, and 1 story.

Updates link to my Tableau Project:
https://public.tableau.com/app/profile/morgan.shoup/viz/Project5-updated/StoryTellingwithDataDashboard?publish=yes
---

## 📂 Files Included in Submission  
- **README.md** (this file)  
- **Project 5.twbx** (Tableau Workbook)  

